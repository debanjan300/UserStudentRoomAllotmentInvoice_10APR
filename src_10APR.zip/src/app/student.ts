import { User } from "./user";

export class Student {
    studentId:number=0;
    user:User=new User();
    guardianFirstName:string="";
    guardianLastName:string="";
    guardianMobile:string="";





    // private Long studentId;
	// private User user;
	// private String guardianFirstName;
	// private String guardianLastName;
	// private Long guardianMobile;
}
