import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InvoiceService {
  url:string='http://localhost:8080/invoice/';

  constructor(private http:HttpClient) { }
  getAllInvoices()
  {
    return this.http.get(this.url);
  }
  findInvoiceById(invoiceId:any)
  {
    return this.http.get(this.url+invoiceId);
  }
  addInvoice(invoice:any)
  {
    return this.http.post(this.url,invoice);
  }
  modifyInvoice(invoice:any)
  {
    return this.http.put(this.url,invoice);
  }
  deleteInvoice(invoiceId:any)
  {
    return this.http.delete(this.url+invoiceId);
  }
  
}
