import { Allotment } from './allotment';

describe('Allotment', () => {
  it('should create an instance', () => {
    expect(new Allotment()).toBeTruthy();
  });
});
