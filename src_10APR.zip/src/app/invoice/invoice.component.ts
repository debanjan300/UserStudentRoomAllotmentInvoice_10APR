import { Component, DoCheck, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Allotment } from '../allotment';
import { AllotmentService } from '../allotment.service';
import { Invoice } from '../invoice';
import { InvoiceService } from '../invoice.service';
import { Student } from '../student';
import { StudentService } from '../student.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit, DoCheck {
  invoices:any;
  role:string="";
  allotments:any;
  studentId:number=0;
  paidAllotmentsByStudent:any;
  unpaidAllotmentsByStudent:any;
  
  loggedRole:string|null="";
  constructor(private is:InvoiceService, private router:Router, private as:AllotmentService, private ss:StudentService) { }
  ngDoCheck(): void {
    var strRole= localStorage.getItem("loggedRole");
   if(strRole!=null)
    this.role=strRole;
    else
      this.role="";
  }

  ngOnInit(): void {
    var loggedUserName=localStorage.getItem("loggedUserName");
    this.loggedRole=localStorage.getItem("loggedRole");
    
    if(loggedUserName==null)
    {
      alert("You have not logged in. Click OK to Login")
    this.router.navigateByUrl('/(col3:Login)');
    }
    else{ 
    this.getAllInvoices();
    this.getPaidAllotmentByStudentId();
    this.getUnPaidAllotmentByStudentId();
      
    }
  }
  fnPayment(a:Allotment)
  {
    alert("Your payment is done. Download your invoice");
    //Long invoiceId, Allotment allotment, Date invoiceDate
    var invoice:Invoice=new Invoice();
    invoice.invoiceDate=new Date();
    invoice.allotment=a;
    this.is.addInvoice(invoice).subscribe((data)=>{
      console.log("fnPayment says:"+data);
      this.getPaidAllotmentByStudentId();
    this.getUnPaidAllotmentByStudentId();
    });
  }
  fnDownloadInvoice()
  {
    alert("Your invoice is downloading!!")
  }

  getAllInvoices() {
    this.is.getAllInvoices().subscribe((data) => {
      console.log(data);
      this.invoices = data;
    });
  }
  getAllAllotments() {
    this.as.getAllAllotment().subscribe((data) => {
      console.log(data);
      this.allotments = data;
    });
  }
  getPaidAllotmentByStudentId()
  {
    var student: Student = new Student();
    // var allotment:Allotment=new Allotment();
    var userName: string | any = localStorage.getItem('loggedUserName');
   this.ss.findStudentByUserName(userName).subscribe((data)=>{
     student= <any>data;
    this.studentId=student.studentId;
    this.as.findPaidAllotmentsByStudentId(this.studentId).subscribe((data1)=>{
      this.paidAllotmentsByStudent=<any>data1;
     // this.getAllAllotments();
    });
   });
  }
  getUnPaidAllotmentByStudentId()
  {
    var student: Student = new Student();
    // var allotment:Allotment=new Allotment();
    var userName: string | any = localStorage.getItem('loggedUserName');
   this.ss.findStudentByUserName(userName).subscribe((data)=>{
     student= <any>data;
    this.studentId=student.studentId;
    this.as.findUnPaidAllotmentsByStudentId(this.studentId).subscribe((data1)=>{
      this.unpaidAllotmentsByStudent=<any>data1;
     // this.getAllAllotments();
    });
   });
  }


}

