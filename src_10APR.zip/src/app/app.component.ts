import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit
{
  loggedFirstName:string|null="";
  loggedRole:string|null="";
  
  ngOnInit(): void {
    this.loggedFirstName=localStorage.getItem("loggedFirstName");
    this.loggedRole=localStorage.getItem("loggedRole");
  }
  title = 'routing-demo';


  
}
