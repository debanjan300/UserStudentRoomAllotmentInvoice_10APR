import { Allotment } from "./allotment";

export class Invoice {
    invoiceId:number=0;
    allotment:Allotment=new Allotment();
    invoiceDate:Date=new Date();
}
