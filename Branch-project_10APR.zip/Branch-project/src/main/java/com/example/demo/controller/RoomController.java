package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Room;
import com.example.demo.service.RoomService;



@RestController
@CrossOrigin(origins= {"http://localhost:4200","*"})
@RequestMapping("/room")
public class RoomController {
	@Autowired
	RoomService rs;
	@GetMapping("/")
	public List<Room> getAllRooms()
	{
		List<Room> rooms = rs.read();
		return rooms;
	}
	@GetMapping("/{roomId}")
	public Room findById(@PathVariable("roomId") Long roomId)
	{
		return rs.read(roomId);
	}
	@PostMapping("/")
	public Room addRoom(@RequestBody Room room)
	{
		return rs.create(room);
	}
	
	@PutMapping("/")
	public Room modifyRoom(@RequestBody Room room)
	{
		return rs.update(room);
	}
	
	@DeleteMapping("/{roomId}")
	public void deleteRoom(@PathVariable("roomId") Long roomId)
	{
		rs.delete(roomId);
	}
	@PutMapping("/roomOccupancy")
	public Room updateRoomOccupancy(@RequestBody Room room, @RequestBody String status)
	{
		return rs.updateRoomOccupancy(room,status);
	}
//	@PutMapping("/allotmentReject")
//	public Room allotmentReject(@RequestBody Room room)
//	{
//		return rs.allotmentReject(room);
//	}

}
