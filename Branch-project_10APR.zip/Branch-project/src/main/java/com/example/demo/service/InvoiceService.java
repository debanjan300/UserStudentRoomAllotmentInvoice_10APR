package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Allotment;
import com.example.demo.entity.Invoice;
import com.example.demo.model.InvoiceRepository;

@Component("is")
public class InvoiceService {

	@Autowired
    private InvoiceRepository invoiceRepo;
    
    public Invoice create(Invoice invoice) 
    {
        return invoiceRepo.save(invoice);
    }
    public List<Invoice> read() 
    {
        return invoiceRepo.findAll();
    }
    public Invoice read(Long invoiceId) 
    {
        return invoiceRepo.findById(invoiceId).get();
    }
    public Invoice update(Invoice invoice) 
    {
        return invoiceRepo.save(invoice);
    }
    public void delete(Long invoiceId) 
    {
        invoiceRepo.delete(read(invoiceId));
    }
   
}
